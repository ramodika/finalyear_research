# --- Standard Library Imports ---
import os
import io
import uuid
import re
import json
import datetime
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import asyncio

# --- FastAPI Imports ---
from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

# --- Data Handling & OCR Imports ---
from PyPDF2 import PdfReader
# Removed scipy.constants import as 'e' was not used

# --- OCR Dependencies ---
try:
    import pytesseract
    from pdf2image import convert_from_bytes
    from PIL import Image # pdf2image returns PIL Images
    OCR_ENABLED = True
except ImportError:
    OCR_ENABLED = False
    # Log warning during startup instead of print
# --- End OCR Dependencies ---

# --- Logging ---
from loguru import logger

# --- In-Memory Data Stores ---
# Using dictionaries to simulate database tables
in_memory_quizzes: Dict[str, Dict[str, Any]] = {}           # {quiz_id: quiz_data}
in_memory_questions: Dict[str, Dict[str, Any]] = {}        # {question_id: question_data}
in_memory_attempts: Dict[int, Dict[str, Any]] = {}         # {attempt_id: attempt_data}
exam_id_to_quiz_id_index: Dict[str, str] = {}              # {exam_id: quiz_id}
exam_id_to_attempt_ids_index: Dict[str, List[int]] = {}    # {exam_id: [attempt_id1, attempt_id2]}
attempt_id_counter = 0                                     # Simple counter for attempt IDs

# Lock for protecting concurrent modifications to the in-memory stores
data_modification_lock = asyncio.Lock()

# --- Vector Store Setup (ChromaDB In-Memory) ---
import chromadb
from chromadb.config import Settings as ChromaSettings
from sentence_transformers import SentenceTransformer
# Use the updated import path if using newer langchain versions
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    from langchain.text_splitter import RecursiveCharacterTextSplitter # Fallback


CHROMA_SETTINGS = ChromaSettings(anonymized_telemetry=False)
chroma_client = chromadb.Client(CHROMA_SETTINGS)
vector_collections: Dict[str, Any] = {} # Keyed by quiz_id

# --- Embedding Model Configuration ---
EMBEDDING_MODEL_NAME = 'all-MiniLM-L6-v2'
embedding_model: Optional[SentenceTransformer] = None

# --- Text Splitting Configuration ---
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=700, chunk_overlap=100, length_function=len, is_separator_regex=False,
)

# --- AI Model Setup ---
# Using Hugging Face Transformers library - Modified for Dual Models
from transformers import AutoModelForSeq2SeqLM, AutoModelForCausalLM, AutoTokenizer

GENERATION_MODEL_NAMES = {
    "t5": "google/flan-t5-small",
    # Use a smaller Phi variant if Phi-4 is too large/not accessible.
    # Adjust if using a different/larger Phi model.
    "phi": "microsoft/phi-1_5" # Example: Using Phi-1.5
    # "phi": "microsoft/Phi-3-mini-4k-instruct" # Example: Using Phi-3 Mini
}
generation_models: Dict[str, Any] = {}         # Stores loaded models {"t5": model, "phi": model}
generation_tokenizers: Dict[str, Any] = {}   # Stores loaded tokenizers {"t5": tokenizer, "phi": tokenizer}
DISABLE_AI_GENERATION = os.getenv("DISABLE_AI_GENERATION", "false").lower() == "true"

# --- Configuration Constants ---
PYPDF2_TEXT_THRESHOLD_PER_PAGE = 50 # Chars per page to trigger OCR fallback
T5_MAX_INPUT_TOKENS = 480           # Max input tokens specifically for the T5 model
PHI_MAX_INPUT_TOKENS = 1024         # Max input tokens for Phi (adjust based on model/memory)
CONTEXT_TOKEN_BUFFER = 50           # Buffer tokens for prompt overhead
OCR_LANGUAGE = 'eng'                # Tesseract language

# --- Static Files and Templates Configuration ---
STATIC_DIR = Path("static")
TEMPLATES_DIR = Path("templates")


# ==============================================================================
# Model Loading Functions (Updated for Dual Models)
# ==============================================================================
def load_embedding_model():
    """Loads the Sentence Transformer model for embeddings."""
    global embedding_model
    if embedding_model is None:
        try:
            logger.info(f"Loading embedding model: {EMBEDDING_MODEL_NAME}...")
            embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
            logger.info("Embedding model loaded successfully.")
        except Exception as e:
            logger.error(f"Fatal: Failed to load embedding model '{EMBEDDING_MODEL_NAME}': {e}.")
            embedding_model = None

def load_generation_models():
    """Loads both T5 and Phi generation models and tokenizers."""
    global generation_models, generation_tokenizers
    if DISABLE_AI_GENERATION:
        logger.warning("AI Question Generation is disabled via environment variable.")
        generation_models, generation_tokenizers = {}, {}
        return

    # --- Load T5 ---
    t5_model_name = GENERATION_MODEL_NAMES.get("t5")
    if t5_model_name and "t5" not in generation_models:
        try:
            logger.info(f"Loading T5 model and tokenizer: {t5_model_name}...")
            generation_tokenizers["t5"] = AutoTokenizer.from_pretrained(t5_model_name)
            generation_models["t5"] = AutoModelForSeq2SeqLM.from_pretrained(
                t5_model_name,
                device_map="auto" # Use GPU if available
            )
            logger.info(f"T5 model '{t5_model_name}' loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load T5 model '{t5_model_name}': {e}. T5 generation will be unavailable.")
            if "t5" in generation_tokenizers: del generation_tokenizers["t5"]
            if "t5" in generation_models: del generation_models["t5"]

    # --- Load Phi ---
    phi_model_name = GENERATION_MODEL_NAMES.get("phi")
    if phi_model_name and "phi" not in generation_models:
        try:
            logger.info(f"Loading Phi model and tokenizer: {phi_model_name}...")
            # Phi often requires trust_remote_code
            generation_tokenizers["phi"] = AutoTokenizer.from_pretrained(phi_model_name, trust_remote_code=True)
            generation_models["phi"] = AutoModelForCausalLM.from_pretrained(
                phi_model_name,
                device_map="auto", # Use GPU if available
                trust_remote_code=True,
                # Add torch_dtype=torch.float16 for potential memory savings if needed
            )
            logger.info(f"Phi model '{phi_model_name}' loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load Phi model '{phi_model_name}': {e}. Phi refinement will be unavailable.")
            if "phi" in generation_tokenizers: del generation_tokenizers["phi"]
            if "phi" in generation_models: del generation_models["phi"]

    if not generation_models:
         logger.error("Fatal: No generation models could be loaded.")

# ==============================================================================
# FastAPI Lifespan Management (Startup / Shutdown)
# ==============================================================================
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handles application startup and shutdown events."""
    logger.info("Application startup sequence initiated...")
    logger.info("Initializing/Clearing in-memory data stores...")
    async with data_modification_lock: # Ensure exclusive access during init
        global in_memory_quizzes, in_memory_questions, in_memory_attempts
        global exam_id_to_quiz_id_index, exam_id_to_attempt_ids_index, attempt_id_counter
        in_memory_quizzes.clear()
        in_memory_questions.clear()
        in_memory_attempts.clear()
        exam_id_to_quiz_id_index.clear()
        exam_id_to_attempt_ids_index.clear()
        attempt_id_counter = 0
    logger.info("In-memory data stores initialized.")

    # --- Load ML Models ---
    load_embedding_model() # Log output inside
    load_generation_models() # Log output inside (Handles T5 and Phi)

    # --- Check Optional Dependencies ---
    if not OCR_ENABLED:
        logger.warning("OCR dependencies (pytesseract/pdf2image) missing or failed import. Image-based PDF processing disabled.")

    # --- Crucial Warning ---
    logger.warning("="*60)
    logger.warning("!!! RUNNING WITH IN-MEMORY STORAGE ONLY !!!")
    logger.warning("!!! All quizzes, questions, and attempts WILL BE LOST on application restart. !!!")
    logger.warning("="*60)

    logger.info("Application startup sequence complete.")
    yield # Application runs after this point

    # --- Shutdown Sequence ---
    logger.info("Application shutdown sequence initiated...")
    logger.info("Clearing in-memory data stores...")
    async with data_modification_lock: # Lock during cleanup as well
        in_memory_quizzes.clear()
        in_memory_questions.clear()
        in_memory_attempts.clear()
        exam_id_to_quiz_id_index.clear()
        exam_id_to_attempt_ids_index.clear()
        vector_collections.clear() # Clear Chroma collection cache
    logger.info("In-memory data stores cleared.")
    # Explicitly reset Chroma client if needed (especially if using persistent storage)
    # global chroma_client
    # chroma_client.reset() # Resets the entire database! Use with caution.
    logger.info("Chroma client (in-memory) does not require explicit shutdown/reset for default usage.")
    logger.info("Application shutdown complete.")


# ==============================================================================
# FastAPI Application Setup
# ==============================================================================
app = FastAPI(
    title="AI Quiz Generator (In-Memory + OCR + Hybrid Gen)",
    description="Generate quizzes from PDFs (OCR for images), refine with T5+Phi, review, publish, take, view results. Data is NOT persisted.",
    version="1.3.0-inmemory-ocr-hybrid",
    lifespan=lifespan # Register the lifespan context manager
)

# --- Mount Static Files ---
if not STATIC_DIR.exists():
    STATIC_DIR.mkdir(parents=True, exist_ok=True)
    logger.info(f"Created static directory at: {STATIC_DIR.resolve()}")
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# --- Setup Jinja2 Templates ---
if not TEMPLATES_DIR.exists():
    logger.warning(f"Templates directory not found at: {TEMPLATES_DIR.resolve()}. Ensure templates are present.")
templates = Jinja2Templates(directory=TEMPLATES_DIR)


# ==============================================================================
# Core Helper Functions (Text Extraction, Context Selection, Parsing)
# ==============================================================================

def extract_text_with_ocr(file_content: bytes, filename: str = "pdf") -> str:
    """
    Attempts text extraction using PyPDF2, falls back to Tesseract OCR if needed.
    (OCR_ENABLED check moved inside the function for clarity)
    """
    text = ""
    num_pages = 0
    min_chars_expected = 0

    # 1. Try PyPDF2
    try:
        reader = PdfReader(io.BytesIO(file_content))
        num_pages = len(reader.pages)
        if num_pages == 0:
            logger.warning(f"[{filename}] PyPDF2 found 0 pages. PDF might be invalid or corrupted.")
        else:
            logger.info(f"[{filename}] Attempting PyPDF2 extraction ({num_pages} pages)...")
            pypdf2_text_parts = []
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    cleaned_page_text = re.sub(r'\s+', ' ', page_text).strip()
                    if cleaned_page_text: pypdf2_text_parts.append(cleaned_page_text)
            text = "\n\n".join(pypdf2_text_parts).strip()
            min_chars_expected = num_pages * PYPDF2_TEXT_THRESHOLD_PER_PAGE
            logger.info(f"[{filename}] PyPDF2 extracted ~{len(text)} characters.")
    except Exception as e_pypdf:
        logger.warning(f"[{filename}] PyPDF2 extraction failed: {e_pypdf}. Will attempt OCR if enabled.")
        text = "" # Reset text

    # 2. Decide OCR Fallback
    # Use OCR if: OCR enabled AND (text too short OR PyPDF2 failed)
    should_use_ocr = OCR_ENABLED and (not text or (num_pages > 0 and len(text) < min_chars_expected))

    if should_use_ocr:
        logger.warning(f"[{filename}] PyPDF2 text length ({len(text)}) seems low or empty. Falling back to OCR.")
        text = "" # Reset text for OCR results
        try:
            logger.info(f"[{filename}] Converting PDF to images for OCR...")
            images = convert_from_bytes(file_content, dpi=300)
            if not images:
                 logger.warning(f"[{filename}] pdf2image failed to convert PDF to images.")
                 return "" # Cannot proceed with OCR if no images

            num_pages = len(images) # Update page count
            logger.info(f"[{filename}] Converted to {num_pages} images. Starting Tesseract OCR...")
            ocr_text_parts = []
            for i, img in enumerate(images):
                try:
                    # Ensure TESSDATA_PREFIX is set if needed, or tesseract is in PATH
                    page_ocr_text = pytesseract.image_to_string(img, lang=OCR_LANGUAGE)
                    if page_ocr_text:
                         cleaned_ocr_text = re.sub(r'\s+', ' ', page_ocr_text).strip()
                         if cleaned_ocr_text: ocr_text_parts.append(cleaned_ocr_text)
                except pytesseract.TesseractNotFoundError:
                     logger.error(f"[{filename}] Tesseract executable not found. Ensure it's installed and in PATH.")
                     # No need to set OCR_ENABLED=False globally here, just fail this attempt
                     return "" # Cannot proceed
                except Exception as e_tess_page:
                    logger.error(f"[{filename}] Tesseract OCR failed on page {i+1}: {e_tess_page}")
                finally: img.close() # Close PIL image

            text = "\n\n".join(ocr_text_parts).strip()
            logger.info(f"[{filename}] OCR completed. Extracted ~{len(text)} characters via Tesseract.")

        except ImportError:
             logger.error(f"[{filename}] OCR failed: pytesseract or pdf2image not installed. Should not happen if OCR_ENABLED is True.")
             text = ""
        except Exception as e_ocr: # Catch poppler errors etc.
            logger.error(f"[{filename}] OCR process failed (maybe Poppler issue?): {e_ocr}")
            text = ""

    # 3. Return Result
    if not text: logger.error(f"[{filename}] Failed to extract significant text using all methods.")
    return text

# --- chunk_text_func ---
def chunk_text_func(text: str) -> List[str]:
    """Chunks text using the configured text splitter."""
    if not text: logger.warning("Attempted to chunk empty text."); return []
    try:
        chunks = text_splitter.split_text(text)
        # Filter out potential empty strings or whitespace-only strings after split
        chunks = [chunk for chunk in chunks if chunk and not chunk.isspace()]
        logger.info(f"Split text into {len(chunks)} non-empty chunks.")
        if not chunks: logger.warning("Text splitting resulted in zero non-empty chunks.")
        return chunks
    except Exception as e: logger.error(f"Error during text splitting: {e}"); return []

# --- vectorize_chunks ---
def vectorize_chunks(chunks: List[str]) -> Optional[List[List[float]]]:
    """Generates embeddings for text chunks."""
    if not embedding_model: logger.error("Cannot vectorize: Embedding model not available."); return None
    if not chunks: logger.warning("No chunks provided to vectorize."); return []
    try:
        logger.info(f"Generating embeddings for {len(chunks)} chunks...")
        # Handle potential numpy arrays from older sentence-transformers, ensure list of lists of floats
        embeddings_raw = embedding_model.encode(chunks, show_progress_bar=False)
        embeddings = [list(map(float, emb)) for emb in embeddings_raw]
        logger.info(f"Embeddings generated successfully.")
        return embeddings
    except Exception as e: logger.exception(f"Error during embedding generation: {e}"); return None

# --- store_chunks_in_vector_db ---
def store_chunks_in_vector_db(quiz_id: str, chunks: List[str], embeddings: List[List[float]]):
    """Stores text chunks and their embeddings in ChromaDB."""
    if not chunks or not embeddings or len(chunks) != len(embeddings):
        logger.error(f"Mismatch/empty data for quiz {quiz_id}. Skipping vector store."); return
    if not quiz_id: logger.error("Invalid quiz_id. Cannot store in vector DB."); return
    try:
        collection_name = f"quiz_{quiz_id}"
        # Check if collection exists, delete if it does to ensure fresh state (optional)
        try:
             if collection_name in [c.name for c in chroma_client.list_collections()]:
                  logger.warning(f"Deleting existing Chroma collection '{collection_name}' before adding new data.")
                  chroma_client.delete_collection(name=collection_name)
             if quiz_id in vector_collections:
                  del vector_collections[quiz_id] # Remove from cache too
        except Exception as e_del_check:
             logger.error(f"Error checking/deleting existing collection '{collection_name}': {e_del_check}")
             # Decide whether to proceed or fail

        collection = chroma_client.get_or_create_collection(name=collection_name)
        vector_collections[quiz_id] = collection # Cache handle

        ids = [f"{quiz_id}_chunk_{i}" for i in range(len(chunks))]
        metadatas = [{"quiz_id": quiz_id, "chunk_index": i} for i in range(len(chunks))]

        # Add in batches if number of chunks is very large (e.g., > 1000)
        batch_size = 500
        for i in range(0, len(chunks), batch_size):
            batch_ids = ids[i:i + batch_size]
            batch_embeddings = embeddings[i:i + batch_size]
            batch_documents = chunks[i:i + batch_size]
            batch_metadatas = metadatas[i:i + batch_size]
            collection.add(ids=batch_ids, embeddings=batch_embeddings, documents=batch_documents, metadatas=batch_metadatas)

        logger.info(f"Stored {len(chunks)} chunks/vectors in Chroma collection '{collection_name}'.")
    except Exception as e:
        logger.exception(f"Error storing data in ChromaDB for quiz {quiz_id}: {e}")
        # Cleanup attempt
        if quiz_id in vector_collections:
            try: chroma_client.delete_collection(name=collection_name); logger.info(f"Cleaned up Chroma collection '{collection_name}' after error.")
            except Exception as del_err: logger.error(f"Failed cleanup of Chroma collection '{collection_name}': {del_err}")
            if quiz_id in vector_collections: del vector_collections[quiz_id]

# --- retrieve_relevant_chunks ---
def retrieve_relevant_chunks(quiz_id: str, query: str, n_results: int = 5) -> List[str]:
    """Retrieves relevant text chunks from ChromaDB."""
    collection_name = f"quiz_{quiz_id}"
    collection = vector_collections.get(quiz_id)
    if not collection:
        try: collection = chroma_client.get_collection(name=collection_name); vector_collections[quiz_id] = collection
        except Exception: logger.warning(f"Vector collection '{collection_name}' not found."); return [] # Expected case
    if not embedding_model: logger.error("Cannot retrieve: Embedding model missing."); return []
    if not query: logger.warning("Empty query for retrieval."); return []
    try:
        logger.info(f"Querying collection '{collection_name}' (n={n_results}) for: '{query[:70]}...'")
        query_embedding = embedding_model.encode([query]).tolist()
        collection_count = collection.count()
        if collection_count == 0: logger.warning(f"Collection '{collection_name}' is empty."); return []
        actual_n_results = min(n_results, collection_count) # Request only available docs

        results = collection.query(query_embeddings=query_embedding, n_results=actual_n_results, include=['documents'])
        retrieved_docs = results.get('documents', [[]])[0] # Get the inner list of documents
        logger.info(f"Retrieved {len(retrieved_docs)} relevant chunk(s) from '{collection_name}'.")
        return retrieved_docs
    except Exception as e: logger.exception(f"Error querying ChromaDB '{collection_name}': {e}"); return []


# --- Context Selection Helper ---
def select_context_within_limit(
    chunks: List[str],
    max_tokens: int,
    tokenizer: Any, # Expect AutoTokenizer instance
    buffer: int = CONTEXT_TOKEN_BUFFER
) -> str:
    """Joins chunks intelligently to fit within token limits for a specific tokenizer."""
    if not chunks: return ""
    if not tokenizer: logger.error("Tokenizer required for select_context_within_limit."); return ""

    context = ""
    current_token_count = 0
    target_token_limit = max_tokens - buffer
    separator = "\n\n"

    for i, chunk in enumerate(chunks):
        next_chunk_text = separator + chunk if context else chunk
        potential_full_context = context + next_chunk_text

        try: # Estimate token count of the *entire* potential context
            # Use truncation=False to get the true count if it fits
            estimated_tokens = len(tokenizer(potential_full_context, truncation=False)['input_ids'])
        except Exception as e_tok:
             logger.warning(f"Token estimation failed: {e_tok}. Using char heuristic."); estimated_tokens = len(potential_full_context) // 3 # Rough fallback

        if estimated_tokens <= target_token_limit:
            context = potential_full_context # Add the chunk
            current_token_count = estimated_tokens
        else: # Token limit would be exceeded
            logger.info(f"Context token limit ({target_token_limit}) reached after adding {i} chunks for model {getattr(tokenizer, 'name_or_path', 'unknown')}. Final estimated tokens: {current_token_count}.")
            break # Stop adding more chunks

    if not context and chunks: # If even the first chunk was too long
        logger.warning(f"First chunk alone exceeds token limit ({target_token_limit}). Truncating first chunk.")
        try: # Use tokenizer for more accurate truncation
             # Ensure truncation happens, don't add special tokens to the count we care about here
             truncated_ids = tokenizer(chunks[0], max_length=target_token_limit, truncation=True, add_special_tokens=False)['input_ids']
             context = tokenizer.decode(truncated_ids, skip_special_tokens=True)
             logger.info(f"Using tokenizer-truncated first chunk (~{len(truncated_ids)} tokens).")
        except Exception: # Fallback: simple character limit
             max_chars = target_token_limit * 4 # Rough estimate
             context = chunks[0][:max_chars]
             logger.info(f"Using character-truncated first chunk (~{len(context)} chars).")

    return context.strip()

# --- T5 Question Parsing (Remains Largely the Same) ---
def parse_t5_generated_questions(raw_text: str, num_expected: int) -> List[Dict[str, Any]]:
    """Parses the raw text output from the T5 model into structured questions."""
    questions = []
    if not raw_text or raw_text.isspace(): logger.warning("Empty T5 text to parse."); return []

    # Split based on pattern: number, period, space at start of line (flexible spacing)
    # Prepending "1. " makes the first split easier if the model omitted it.
    potential_questions = re.split(r'\n\s*(?=\d+\.\s)', ("1. " + raw_text).strip())
    logger.info(f"Attempting to parse {len(potential_questions)} potential T5 question blocks.")

    # Regex: more robust to variations like extra spaces, case changes
    pattern = re.compile(
        # r'^(?:\d+\.\s*)?(?P<question>.*?)\s+' # Optional number.dot, Question text
        r'^(?P<question>.*?)\s+'           # Question text (non-greedy) - number removed by split logic
        r'[Aa]\)\s*(?P<opt_a>.*?)\s+'        # Option A (allow 'a)' or 'A)')
        r'[Bb]\)\s*(?P<opt_b>.*?)\s+'        # Option B
        r'[Cc]\)\s*(?P<opt_c>.*?)\s+'        # Option C
        r'[Dd]\)\s*(?P<opt_d>.*?)\s+'        # Option D
        r'Answer:\s*(?P<answer>[A-Da-d])', # Answer: A-D (case-insensitive)
        re.DOTALL | re.MULTILINE
    )

    for i, block in enumerate(potential_questions):
        block_cleaned = re.sub(r'^\d+\.\s*', '', block.strip()).strip() # Clean leading num. again just in case
        if not block_cleaned: continue

        match = pattern.search(block_cleaned)
        if match:
            data = match.groupdict()
            question_text = data['question'].strip()
            options_list = [data[k].strip() for k in ['opt_a', 'opt_b', 'opt_c', 'opt_d']]
            correct_answer_char = data['answer'].upper() # Standardize

            # Validation
            if not question_text or not all(opts for opts in options_list) or len(options_list) != 4:
                logger.warning(f"Parsed empty Q or missing/invalid Option in T5 block {i+1}. Skipping.")
                continue

            try: # Convert answer char to index
                correct_index = ['A', 'B', 'C', 'D'].index(correct_answer_char)
                questions.append({
                    "question": question_text, "options": options_list, "correct_answer_index": correct_index
                })
                # Don't break early, parse all valid ones T5 might have generated
            except ValueError: logger.warning(f"Invalid answer char '{correct_answer_char}' in T5 block {i+1}."); continue
        else:
            logger.warning(f"Could not parse T5 structure in block {i+1}: '{block_cleaned[:100]}...'")

    # Final Logging & Trimming
    if not questions: logger.error("Failed to parse ANY valid questions from T5 generated text.")
    elif len(questions) != num_expected: logger.warning(f"Parsed {len(questions)}/{num_expected} valid questions from T5.")

    return questions[:num_expected] # Return only the number requested, even if more were parsed

# --- Phi-Refined Question Parsing ---
def parse_phi_refined_question(raw_text: str) -> Optional[Dict[str, Any]]:
    """
    Parses the potentially less structured output from Phi refinement.
    Looks for Question, A) B) C) D) Options, and Answer: X pattern.
    """
    if not raw_text or raw_text.isspace(): return None

    # Try to extract the core components using flexible regex
    q_match = re.search(r"^(?:Improved Question:|Q:)\s*(?P<question>.*?)(?=\n\s*[Aa]\)|$)", raw_text, re.IGNORECASE | re.DOTALL)
    question_text = q_match.group('question').strip() if q_match else None

    opts = {}
    for char_code in range(65, 69): # A=65, B=66, C=67, D=68
        char = chr(char_code)
        # Look for X) option text, ending before the next option or "Answer:" or end of string
        opt_pattern = rf"[{char.lower()}{char.upper()}]\)\s*(?P<option>.*?)(?=\n\s*[{chr(char_code+1).lower()}{chr(char_code+1).upper()}]\)|Answer:|Select an option:|\Z)"
        opt_match = re.search(opt_pattern, raw_text, re.DOTALL | re.IGNORECASE)
        if opt_match:
            opts[char] = opt_match.group('option').strip()

    # Check if we got all 4 options
    if len(opts) != 4 or not all(opts.get(c) for c in "ABCD"):
        logger.warning(f"Phi Parser: Failed to find all 4 options. Found: {list(opts.keys())}. Text: '{raw_text[:150]}...'")
        return None # Could not parse all required options

    options_list = [opts['A'], opts['B'], opts['C'], opts['D']]

    # Find the answer
    ans_match = re.search(r"Answer:\s*(?P<answer>[A-Da-d])", raw_text, re.IGNORECASE)
    correct_answer_char = ans_match.group('answer').upper() if ans_match else None

    if not question_text or not correct_answer_char:
        logger.warning(f"Phi Parser: Missing question or answer. Q: {bool(question_text)}, Ans: {bool(correct_answer_char)}. Text: '{raw_text[:150]}...'")
        return None

    try:
        correct_index = ['A', 'B', 'C', 'D'].index(correct_answer_char)
        return {
            "question": question_text,
            "options": options_list,
            "correct_answer_index": correct_index
        }
    except ValueError:
        logger.warning(f"Phi Parser: Invalid answer character '{correct_answer_char}'.")
        return None


# --- Hybrid Question Generation ---
def generate_hybrid_quiz_questions(context: str, num_questions: int) -> Tuple[List[Dict[str, Any]], str]:
    """
    Generates questions using T5, then attempts refinement using Phi.
    Returns the list of questions and a status message.
    """
    generation_status = "Generation not started."
    if DISABLE_AI_GENERATION: return [], "AI generation disabled."
    if not generation_models or not generation_tokenizers: return [], "Generation models/tokenizers not loaded."
    if not context: return [], "No context provided for generation."
    if num_questions <= 0: return [], f"Invalid number of questions requested: {num_questions}."

    # --- Step 1: Generate with T5 ---
    t5_model = generation_models.get("t5")
    t5_tokenizer = generation_tokenizers.get("t5")
    t5_questions = []
    t5_raw_output = ""

    if t5_model and t5_tokenizer:
        try:
            # Prepare T5 Input (uses T5 specific limits)
            t5_prompt = f"""Based ONLY on the following text, generate exactly {num_questions} multiple-choice question(s).
Each question MUST:
1. Start with the question number followed by a period (e.g., 1.).
2. Have exactly 4 options labeled A), B), C), and D).
3. Clearly indicate the single correct answer letter after the options using the format 'Answer: X'.
4. Be relevant to the main points of the provided text.
Do not use any external knowledge.

Context Text:
\"\"\"
{context}
\"\"\"

Questions:
1."""
            inputs = t5_tokenizer(
                t5_prompt, return_tensors="pt", max_length=T5_MAX_INPUT_TOKENS,
                truncation=True # Safeguard truncation based on T5 limit
            )
            input_len = inputs['input_ids'].shape[1]
            logger.info(f"Generating {num_questions} initial Qs with T5 (input tokens: {input_len})...")

            if hasattr(t5_model, 'device') and hasattr(inputs, 'to'):
                try: inputs = inputs.to(t5_model.device)
                except Exception as e_dev: logger.error(f"Failed move T5 inputs to device {t5_model.device}: {e_dev}.")

            # T5 Generation parameters
            max_len_output = max(150, (num_questions * 140))
            max_len_output = min(max_len_output, getattr(t5_model.config, 'max_length', 512))

            outputs = t5_model.generate(
                **inputs, max_length=max_len_output, num_beams=4, temperature=0.75,
                early_stopping=True, no_repeat_ngram_size=2
            )
            t5_raw_output = t5_tokenizer.decode(outputs[0], skip_special_tokens=True)
            logger.debug(f"Raw T5 output:\n---\n{t5_raw_output}\n---")
            t5_questions = parse_t5_generated_questions(t5_raw_output, num_questions)
            # Log the structured T5 output
            logger.info(f"Parsed T5 questions (structured):\n{json.dumps(t5_questions, indent=2)}")

            generation_status = f"Generated {len(t5_questions)}/{num_questions} Qs via T5."
            if not t5_questions: generation_status += " (Parsing failed)"

        except Exception as e:
            logger.exception(f"Error during T5 generation: {e}")
            generation_status = "Error during T5 generation."
            t5_questions = []
    else:
        generation_status = "T5 model not available. Cannot generate initial questions."
        return [], generation_status

    # --- Step 2: Refine with Phi (if T5 succeeded) ---
    phi_model = generation_models.get("phi")
    phi_tokenizer = generation_tokenizers.get("phi")
    refined_questions = []
    refinement_skipped = 0
    refinement_failed = 0

    if phi_model and phi_tokenizer and t5_questions:
        logger.info(f"Attempting refinement of {len(t5_questions)} questions with Phi...")
        for i, q_data in enumerate(t5_questions):
            try:
                # Prepare Phi Input (uses Phi specific limits potentially)
                # Simple refinement prompt
                phi_prompt = f"""Improve the following multiple-choice question based on general knowledge and clarity, while keeping the core topic. Ensure there are 4 options (A, B, C, D) and a single clear correct answer indicated by 'Answer: X'.

Original Question:
Q: {q_data['question']}
Options:
A) {q_data['options'][0]}
B) {q_data['options'][1]}
C) {q_data['options'][2]}
D) {q_data['options'][3]}
Answer: {chr(65 + q_data['correct_answer_index'])}

Improved Question:
Q:""" # Let Phi complete from here

                # Tokenize for Phi, apply its own limits if necessary
                inputs = phi_tokenizer(
                    phi_prompt, return_tensors="pt", max_length=PHI_MAX_INPUT_TOKENS,
                    truncation=True # Safeguard based on Phi's limits
                )
                input_len = inputs['input_ids'].shape[1]
                # logger.debug(f"Refining Q{i+1} with Phi (input tokens: {input_len})") # Verbose

                if hasattr(phi_model, 'device') and hasattr(inputs, 'to'):
                     try: inputs = inputs.to(phi_model.device)
                     except Exception as e_dev: logger.error(f"Failed move Phi inputs to device {phi_model.device}: {e_dev}.")

                # Phi Generation Parameters (Causal LM typically needs different settings)
                # Adjust max_new_tokens based on expected output size
                outputs = phi_model.generate(
                    **inputs,
                    max_new_tokens=200, # Max tokens *to generate*, not total length
                    temperature=0.7,
                    top_k=50,
                    # top_p=0.9, # Alternative sampling
                    do_sample=True, # Use sampling
                    pad_token_id=phi_tokenizer.eos_token_id # Important for Causal LMs
                )
                # Decode only the generated part, skipping the prompt
                phi_raw_output = phi_tokenizer.decode(outputs[0][input_len:], skip_special_tokens=True)
                logger.debug(f"Raw Phi refinement output for Q{i+1}:\n---\n{phi_raw_output}\n---")

                # Parse the refined output
                refined_q = parse_phi_refined_question("Q:" + phi_raw_output) # Prepend Q: to help parser
                # Log the structured Phi output
                logger.info(f"Parsed Phi refinement output for Q{i+1} (structured):\n{json.dumps(refined_q, indent=2) if refined_q else 'None'}")


                if refined_q:
                    refined_questions.append(refined_q)
                else:
                    logger.warning(f"Phi refinement parsing failed for Q{i+1}. Using original T5 question.")
                    refined_questions.append(q_data) # Fallback to original
                    refinement_failed += 1

            except Exception as e:
                 logger.exception(f"Error during Phi refinement for Q{i+1}: {e}")
                 refined_questions.append(q_data) # Fallback to original on error
                 refinement_failed += 1
        # Update status after refinement loop
        refined_count = len(t5_questions) - refinement_skipped - refinement_failed
        generation_status += f" Phi refinement: {refined_count} successful, {refinement_failed} failed/fallback, {refinement_skipped} skipped."

    elif not (phi_model and phi_tokenizer):
        generation_status += " Phi model not available, skipping refinement."
        refined_questions = t5_questions # Use T5 results directly
    elif not t5_questions:
        # Status already reflects T5 failure
        refined_questions = []
    else: # Phi available, but T5 failed
        refined_questions = [] # Should be empty anyway

    # Final check
    if not refined_questions and t5_questions:
        logger.warning("Refinement process resulted in zero questions, falling back to original T5 questions.")
        refined_questions = t5_questions
        generation_status += " (Fell back to T5 Qs post-refinement)."

    logger.info(f"Hybrid Generation Final Status: {generation_status}")
    return refined_questions, generation_status


# ==============================================================================
# API Endpoints
# ==============================================================================

# --- HTML Serving Endpoints ---
@app.get("/", response_class=HTMLResponse, name="home", tags=["HTML Pages"])
async def read_home(request: Request):
    """Serves the main homepage."""
    return templates.TemplateResponse("index.html", {"request": request, "current_year": datetime.datetime.now().year})

@app.get("/take", response_class=HTMLResponse, name="take_entry", tags=["HTML Pages"])
async def read_take_entry(request: Request):
    """Serves the page for entering an Exam ID."""
    return templates.TemplateResponse("take_entry.html", {"request": request, "current_year": datetime.datetime.now().year})

@app.get("/quiz/{exam_id}/take", response_class=HTMLResponse, name="take_quiz", tags=["HTML Pages"])
async def read_take_quiz_form(request: Request, exam_id: str):
    """Serves the quiz taking form for a specific Exam ID."""
    exam_id_upper = exam_id.strip().upper()
    quiz_id = exam_id_to_quiz_id_index.get(exam_id_upper)
    quiz_record = in_memory_quizzes.get(quiz_id) if quiz_id else None
    error_message = None
    questions_for_taker = []
    quiz_filename = "Quiz"
    status_code = 200

    if not quiz_record or quiz_record.get("status") != 'published':
        error_message = f"No published quiz found for Exam ID: {exam_id_upper}."
        status_code = 404
        logger.warning(f"Attempt to take non-existent/non-published quiz: {exam_id_upper}")
    else:
        quiz_filename = quiz_record.get("filename", "Quiz") or "Quiz"
        # Access questions carefully, guarding against partial states if possible
        quiz_questions_data = [q for q in in_memory_questions.values() if q.get("quiz_id") == quiz_id]

        if not quiz_questions_data:
            error_message = "Quiz has no questions."
            logger.error(f"Published quiz {exam_id_upper} (quiz_id: {quiz_id}) has no questions in memory.")
            # Consider status code 500 Internal Server Error? 404 implies no quiz, but quiz exists without Qs.
            # Let's keep 404 for consistency with 'quiz not found' feel for the user.
            status_code = 404
        else:
            quiz_questions_data.sort(key=lambda q: q.get("order", float('inf')))
            # Select only question text and options for the taker
            questions_for_taker = [
                {"question": q.get("question_text"), "options": q.get("options")}
                for q in quiz_questions_data
            ]
            logger.info(f"Prepared {len(questions_for_taker)} questions for taking quiz {exam_id_upper}.")

    return templates.TemplateResponse(
        "take_quiz.html",
        {
            "request": request,
            "exam_id": exam_id_upper,
            "quiz_filename": quiz_filename,
            "questions": questions_for_taker,
            "error": error_message,
            "current_year": datetime.datetime.now().year
        },
        status_code=status_code
    )

@app.get("/results", response_class=HTMLResponse, name="view_results", tags=["HTML Pages"])
async def read_view_results(request: Request):
    """Serves the page for entering an Exam ID to view results."""
    return templates.TemplateResponse("view_results.html", {"request": request, "current_year": datetime.datetime.now().year})

# --- Data API Endpoints ---

@app.post("/upload-and-generate/", response_class=JSONResponse, tags=["Quiz Creation"])
async def upload_process_generate(
    request: Request,
    pdf_file: UploadFile = File(...),
    num_questions: int = Form(1, ge=1, le=25), # Min 1 question requested
):
    """
    Handles PDF upload, OCR, text processing, HYBRID AI question generation (T5+Phi), saves draft IN MEMORY.
    """
    start_time = datetime.datetime.now()
    filename = pdf_file.filename or "unknown.pdf"
    logger.info(f"Request: Generate {num_questions} questions from '{filename}'.")

    # --- File Handling ---
    if not filename.lower().endswith(".pdf"): raise HTTPException(status_code=400, detail="Invalid file type. Only PDF files are accepted.")
    try: contents = await pdf_file.read()
    except Exception as e: logger.error(f"Read fail: {e}"); raise HTTPException(status_code=400, detail="Failed to read uploaded file.")
    finally: await pdf_file.close()
    if not contents: raise HTTPException(status_code=400, detail="Empty file uploaded.")

    # --- Text Extraction ---
    extracted_text = extract_text_with_ocr(contents, filename=filename)
    if not extracted_text or extracted_text.isspace():
        logger.error(f"Failed to extract text from '{filename}'. Cannot generate quiz.")
        raise HTTPException(status_code=400, detail="Could not extract readable text from PDF. Check if the PDF contains text or is image-only (OCR might have failed).")

    # --- Create Draft Quiz (Protected by Lock) ---
    quiz_id = str(uuid.uuid4())
    quiz_entry = { "id": quiz_id, "exam_id": None, "filename": filename, "status": "draft", "created_at": datetime.datetime.utcnow(), "published_at": None }
    async with data_modification_lock:
        in_memory_quizzes[quiz_id] = quiz_entry
    logger.info(f"Created draft quiz {quiz_id} for '{filename}'.")

    # --- Text Processing & Vector Store ---
    chunks = chunk_text_func(extracted_text)
    embeddings = None
    if chunks and embedding_model:
        embeddings = vectorize_chunks(chunks)
    if chunks and embeddings:
        store_chunks_in_vector_db(quiz_id, chunks, embeddings)
    else:
        logger.info(f"Skipping vector store for {quiz_id} (no chunks/embeddings).")

    # --- Prepare Context for Generation (Primarily for T5) ---
    context_for_generation = ""
    context_source = "N/A"
    # Determine which tokenizer to use for context limit (T5 is the first stage)
    context_tokenizer = generation_tokenizers.get("t5")
    context_max_tokens = T5_MAX_INPUT_TOKENS

    if chunks:
        source_chunks = chunks # Start with all chunks
        if embeddings: # Try RAG
            retrieved = retrieve_relevant_chunks(quiz_id, "Key information, main topics, facts, definitions, concepts.", n_results=10)
            if retrieved: source_chunks = retrieved; context_source = f"{len(retrieved)} retrieved chunks"
            else: source_chunks = chunks[:max(1, len(chunks)//2)]; context_source = "first half chunks (retrieval failed)" # Fallback to first half
        else: source_chunks = chunks[:max(3, len(chunks)//2)]; context_source = f"first few chunks (no embeds)" # Fallback if no embeddings

        # Select within token limits using the appropriate tokenizer (T5's)
        if context_tokenizer:
            context_for_generation = select_context_within_limit(source_chunks, context_max_tokens, context_tokenizer)
            logger.info(f"Selected context ({context_source}). Length: ~{len(context_for_generation)} chars for T5 input.")
        else: # Fallback if T5 tokenizer not loaded, less accurate
            context_for_generation = "\n\n".join(source_chunks)[:(context_max_tokens * 4)]; logger.error("T5 Tokenizer N/A, using character-limited context for generation.")

    elif extracted_text: # Fallback: Use raw text start if no chunks
        context_for_generation = extracted_text[:(context_max_tokens * 4)]; context_source = "start of raw text"; logger.warning(f"No chunks. Using {context_source}.")

    if not context_for_generation: logger.error(f"Cannot prepare ANY context for {quiz_id}.")

    # --- Generate Questions using Hybrid Approach ---
    generated_questions = []
    generation_info = "AI generation not attempted (check config/models)."
    if DISABLE_AI_GENERATION: generation_info = "AI generation disabled."
    elif not generation_models: generation_info = "No generation models available."
    elif not context_for_generation: generation_info = "No context prepared for generation."
    else: # Attempt generation
        logger.info(f"Attempting HYBRID AI gen ({num_questions} Qs) from context ({context_source})...")
        # Call the new hybrid function
        generated_questions, generation_info = generate_hybrid_quiz_questions(context_for_generation, num_questions)
        # Generation info is now set by the hybrid function itself

    # --- Save Generated Questions (Protected by Lock) ---
    questions_for_review = []; save_error = False
    if generated_questions:
        new_q_map = {}
        try:
            for i, q_data in enumerate(generated_questions):
                q_id = str(uuid.uuid4())
                # Use the keys returned by the parsers ('question', 'options', 'correct_answer_index')
                # Standardize to DB/API keys here ('question_text')
                entry = {
                    "id": q_id,
                    "quiz_id": quiz_id,
                    "order": i,
                    "question_text": q_data.get("question"),
                    "options": q_data.get("options"),
                    "correct_answer_index": q_data.get("correct_answer_index")
                 }
                # Basic validation before adding
                if entry["question_text"] and entry["options"] and isinstance(entry["options"], list) and len(entry["options"]) == 4 and isinstance(entry["correct_answer_index"], int):
                    new_q_map[q_id] = entry
                    questions_for_review.append(entry) # Send full entry to UI now
                else:
                    logger.warning(f"Skipping invalid question structure generated/parsed for quiz {quiz_id} at index {i}.")

            if new_q_map:
                async with data_modification_lock:
                    in_memory_questions.update(new_q_map)
                logger.info(f"Saved {len(new_q_map)} valid Qs in memory for {quiz_id}.")
                # Adjust generation_info if number saved differs from number generated
                if len(new_q_map) != len(generated_questions):
                    generation_info += f" (Saved {len(new_q_map)} valid Qs)."
            elif generated_questions: # Generated something but nothing valid saved
                 generation_info += " (Generated Qs were invalid/malformed)."

        except Exception as e:
            logger.exception(f"Error saving Qs in memory for {quiz_id}: {e}");
            questions_for_review = []; save_error = True; generation_info += " (Save Error)"

    # --- Prepare Response ---
    end_time = datetime.datetime.now(); proc_time = (end_time - start_time).total_seconds()
    logger.info(f"Process {quiz_id} finished in {proc_time:.2f}s. Status: {generation_info}")
    response_content = {
        "draft_quiz_id": quiz_id,
        "questions": questions_for_review, # Send the validated questions
        "generation_info": generation_info,
        "processing_time_seconds": round(proc_time, 2)
    }
    status_code = 200 # Default to 200 OK
    response_content["detail"] = generation_info # Use the detailed status as the primary detail

    if save_error:
        response_content["detail"] += " (Failed to save questions)"
        status_code = 500 # Internal Server Error
    elif not questions_for_review and context_for_generation and not DISABLE_AI_GENERATION and generation_models:
        response_content["detail"] = "AI generation attempted but yielded no valid/parseable questions. The context might be unsuitable or the models failed to produce the required format."
        # Keep status 200 as draft was created, but indicate failure in message
    elif not context_for_generation and extracted_text:
        response_content["detail"] = "Quiz draft created, but no usable context could be prepared for AI question generation."
        # Keep status 200

    return JSONResponse(content=response_content, status_code=status_code)


# --- publish_quiz_endpoint ---
@app.post("/publish-quiz/", response_class=JSONResponse, tags=["Quiz Creation"])
async def publish_quiz_endpoint(request: Request):
    """Publishes a draft quiz using in-memory stores, including edited questions."""
    draft_quiz_id: Optional[str] = None
    try:
        payload = await request.json(); draft_quiz_id = payload.get("draft_quiz_id"); edited_questions_payload = payload.get("questions")
        if not draft_quiz_id: raise HTTPException(status_code=400, detail="Missing 'draft_quiz_id'.")
        if not isinstance(edited_questions_payload, list): raise HTTPException(status_code=400, detail="'questions' must be a list.")
        logger.info(f"Request to publish quiz: {draft_quiz_id}")

        async with data_modification_lock:
            # --- Fetch and Validate Draft ---
            quiz_record = in_memory_quizzes.get(draft_quiz_id)
            if not quiz_record or quiz_record.get("status") != 'draft':
                raise HTTPException(status_code=404, detail=f"Draft quiz '{draft_quiz_id}' not found or already published.")

            # --- Process Questions (Update/Insert/Delete) ---
            original_q_ids = { q_id for q_id, q_data in in_memory_questions.items() if q_data.get("quiz_id") == draft_quiz_id }
            processed_ids = set(); updates = {}; inserts = {}
            final_question_count = 0
            for i, q_data in enumerate(edited_questions_payload):
                # Expect keys from the UI/frontend: question_text, options, correct_answer_index, potentially id
                q_id = q_data.get("id") # May be null/missing for new Qs added in UI
                q_text = q_data.get("question_text", "").strip();
                q_opts = q_data.get("options");
                q_idx = q_data.get("correct_answer_index")

                # Robust validation of incoming data
                is_valid = (
                    q_text and
                    isinstance(q_opts, list) and
                    len(q_opts) == 4 and
                    all(isinstance(opt, str) and opt.strip() for opt in q_opts) and
                    isinstance(q_idx, int) and 0 <= q_idx < 4
                )
                if not is_valid:
                    logger.warning(f"Skipping invalid question data at index {i} during publish for {draft_quiz_id}. Data: {str(q_data)[:100]}...")
                    continue

                # This is a valid question to be included
                final_question_count += 1
                # Store using consistent keys
                store_data = {
                    "quiz_id": draft_quiz_id,
                    "order": i,
                    "question_text": q_text,
                    "options": [opt.strip() for opt in q_opts], # Store cleaned options
                    "correct_answer_index": q_idx
                }

                # Check if it's an existing question being updated or a new one
                q_id_str = str(q_id) if q_id else None # Handle potential non-string IDs from frontend
                if q_id_str and q_id_str in original_q_ids: # Existing? -> Update
                    processed_ids.add(q_id_str);
                    store_data["id"] = q_id_str; # Ensure ID is stored
                    updates[q_id_str] = store_data
                else: # New or ID mismatch? -> Insert as New
                    new_q_id = str(uuid.uuid4())
                    processed_ids.add(new_q_id);
                    store_data["id"] = new_q_id;
                    inserts[new_q_id] = store_data
                    if q_id_str: logger.warning(f"Received question with ID '{q_id_str}' not found in original draft questions for {draft_quiz_id}. Treating as new question {new_q_id}.")


            # Check if there are any questions left to publish
            if final_question_count == 0:
                 raise HTTPException(status_code=400, detail="Cannot publish quiz with zero valid questions after review.")

            # Apply changes to in_memory_questions
            upd_c, ins_c, del_c = 0, 0, 0
            # Update existing ones
            for qid, data in updates.items():
                if qid in in_memory_questions:
                    in_memory_questions[qid].update(data)
                    upd_c += 1
            # Insert new ones
            if inserts:
                in_memory_questions.update(inserts)
                ins_c = len(inserts)
            # Delete questions that were in the draft but not in the final submission
            ids_to_del = original_q_ids - processed_ids
            for qid in ids_to_del:
                if qid in in_memory_questions:
                    del in_memory_questions[qid]
                    del_c += 1
            logger.info(f"Publish {draft_quiz_id}: Updated {upd_c}, Inserted {ins_c}, Deleted {del_c}. Final questions: {final_question_count}.")

            # --- Generate Exam ID ---
            exam_id = ""; max_attempts = 20 # Increased attempts just in case
            for attempt in range(max_attempts):
                # Generate a sufficiently random ID (8 hex chars = 4 bytes = ~4 billion combos)
                temp_id = str(uuid.uuid4().hex[:8]).upper()
                if temp_id not in exam_id_to_quiz_id_index: # Check index for collision
                    exam_id = temp_id
                    break # Found a unique ID, exit loop
            if not exam_id:
                logger.error(f"Could not generate unique Exam ID for {draft_quiz_id} after {max_attempts} attempts. High collision rate or logic error.")
                raise HTTPException(status_code=500, detail="Failed to generate unique Exam ID. Please try again later.")

            # --- Update Quiz Record and Index ---
            quiz_record.update({
                "status": "published",
                "exam_id": exam_id,
                "published_at": datetime.datetime.utcnow()
            })
            # No need to update in_memory_quizzes[draft_quiz_id] again as dict update is in-place
            exam_id_to_quiz_id_index[exam_id] = draft_quiz_id # Add to index

            logger.info(f"Quiz {draft_quiz_id} published as Exam ID: {exam_id}")
            return JSONResponse(content={"exam_id": exam_id, "message": f"Quiz published successfully with Exam ID: {exam_id}"})

    except HTTPException as he: raise he # Re-raise validation/not found errors
    except Exception as e: logger.exception(f"Unexpected error publishing quiz {draft_quiz_id or '?'}: {e}"); raise HTTPException(status_code=500, detail="Unexpected server error during publishing.")


# --- submit_quiz_answers ---
@app.post("/submit/{exam_id}", response_class=JSONResponse, tags=["Quiz Taking"])
async def submit_quiz_answers(exam_id: str, request: Request):
    """Handles quiz submission, grades answers, and stores attempt IN MEMORY."""
    exam_id_upper = exam_id.strip().upper()
    logger.info(f"Receiving submission for: {exam_id_upper}")
    try:
        # --- Validate Exam ID and Fetch Quiz (Read-only access, no lock needed yet) ---
        quiz_id = exam_id_to_quiz_id_index.get(exam_id_upper)
        if not quiz_id: raise HTTPException(status_code=404, detail=f"Exam ID '{exam_id_upper}' not found.")
        quiz_record = in_memory_quizzes.get(quiz_id)
        if not quiz_record or quiz_record.get("status") != 'published': raise HTTPException(status_code=404, detail=f"Quiz '{exam_id_upper}' is not published or does not exist.")

        # --- Fetch and Order Questions (Read-only access, no lock needed) ---
        questions = sorted([q for q in in_memory_questions.values() if q.get("quiz_id") == quiz_id], key=lambda q: q.get("order", float('inf')))
        if not questions: logger.error(f"Cannot grade {exam_id_upper}: No questions found for quiz ID {quiz_id}."); raise HTTPException(status_code=500, detail="Internal error: Cannot retrieve questions for grading.")
        correct_answers = [q["correct_answer_index"] for q in questions]; total_q = len(correct_answers)

        # --- Parse Submission ---
        try:
            submission = await request.json()
            submitted_answers_raw = submission.get("answers") # Expect a list from frontend
        except json.JSONDecodeError: raise HTTPException(status_code=400, detail="Invalid submission format. Expected JSON.")
        if not isinstance(submitted_answers_raw, list): raise HTTPException(status_code=400, detail="Invalid submission format. 'answers' field must be a list.")
        if len(submitted_answers_raw) != total_q: raise HTTPException(status_code=400, detail=f"Incorrect number of answers submitted. Expected {total_q}, received {len(submitted_answers_raw)}.")

        # --- Grade Submission ---
        score = 0; taker_answers_validated: List[Optional[int]] = [] # Store validated answers (0-3 or None)
        for i in range(total_q):
            raw_ans = submitted_answers_raw[i]; answer_index: Optional[int] = None
            if raw_ans is not None: # Allow for skipped questions (None)
                try:
                    ans_int = int(raw_ans)
                    if 0 <= ans_int < 4: # Validate index range (0, 1, 2, 3)
                        answer_index = ans_int
                    else: logger.warning(f"Invalid answer value '{raw_ans}' for Q{i+1} in {exam_id_upper}. Treating as unanswered.")
                except (ValueError, TypeError): logger.warning(f"Non-integer answer value '{raw_ans}' for Q{i+1} in {exam_id_upper}. Treating as unanswered.")
            taker_answers_validated.append(answer_index)
            # Check score
            if answer_index is not None and answer_index == correct_answers[i]:
                score += 1
        percentage = round((score / total_q) * 100, 2) if total_q > 0 else 0.0

        # --- Store Attempt (Protected by Lock) ---
        async with data_modification_lock:
            global attempt_id_counter; attempt_id_counter += 1; new_attempt_id = attempt_id_counter
            attempt_entry = {
                "id": new_attempt_id,
                "quiz_id": quiz_id,
                "exam_id": exam_id_upper,
                "score": score,
                "total_questions": total_q,
                "percentage": percentage,
                "submitted_at": datetime.datetime.utcnow(),
                "taker_answers": taker_answers_validated # Store the validated answers
             }
            in_memory_attempts[new_attempt_id] = attempt_entry
            # Update index
            if exam_id_upper not in exam_id_to_attempt_ids_index: exam_id_to_attempt_ids_index[exam_id_upper] = []
            exam_id_to_attempt_ids_index[exam_id_upper].append(new_attempt_id)

        logger.info(f"Graded & Saved submission for {exam_id_upper} (Attempt ID {new_attempt_id}): Score {score}/{total_q} ({percentage:.2f}%)")
        return JSONResponse(content={ "exam_id": exam_id_upper, "score": score, "total_questions": total_q, "percentage": percentage, "attempt_id": new_attempt_id, "message": "Quiz submitted and graded successfully." })
    except HTTPException as he: raise he
    except Exception as e: logger.exception(f"Error processing submission for {exam_id_upper}: {e}"); raise HTTPException(status_code=500, detail="Unexpected server error during submission processing.")


# --- get_quiz_results_data ---
@app.get("/results/{exam_id}", response_class=JSONResponse, tags=["Results"])
async def get_quiz_results_data(exam_id: str):
    """Returns aggregated results data for a quiz from in-memory store."""
    exam_id_upper = exam_id.strip().upper(); logger.info(f"Requesting results for: {exam_id_upper}")

    # --- Validate Exam ID (Read-only, no lock needed) ---
    quiz_id = exam_id_to_quiz_id_index.get(exam_id_upper)
    if not quiz_id: raise HTTPException(status_code=404, detail=f"Exam ID '{exam_id_upper}' not found.")
    quiz_record = in_memory_quizzes.get(quiz_id) # Fetch quiz details like filename if needed
    if not quiz_record: logger.error(f"Data inconsistency: Exam ID {exam_id_upper} found in index but Quiz {quiz_id} not in main store."); raise HTTPException(status_code=500, detail="Internal data inconsistency.")

    # --- Get Attempts (Read-only, no lock needed) ---
    attempt_ids = exam_id_to_attempt_ids_index.get(exam_id_upper, [])
    attempts = [in_memory_attempts[aid] for aid in attempt_ids if aid in in_memory_attempts]

    # --- Calculate Stats ---
    total_questions = 0
    # Find total questions from first attempt, or query questions if no attempts
    if attempts: total_questions = attempts[0].get("total_questions", 0)
    if not total_questions: # Fallback if first attempt missing data or no attempts yet
         total_questions = sum(1 for q in in_memory_questions.values() if q.get("quiz_id") == quiz_id)

    if not attempts:
        logger.info(f"No attempts found for {exam_id_upper}.")
        return JSONResponse(content={
            "exam_id": exam_id_upper,
            "filename": quiz_record.get("filename", "N/A"),
            "attempts": 0,
            "average_score": 0.0,
            "average_percentage": 0.0,
            "score_distribution": {}, # Empty distribution
            "total_questions": total_questions,
            "message": "No attempts have been recorded for this quiz yet."
        })

    total_attempts = len(attempts)
    total_score_sum = sum(a.get("score", 0) for a in attempts)
    total_percentage_sum = sum(a.get("percentage", 0.0) for a in attempts)

    average_score = round(total_score_sum / total_attempts, 2) if total_attempts > 0 else 0.0
    average_percentage = round(total_percentage_sum / total_attempts, 2) if total_attempts > 0 else 0.0

    # Calculate score distribution (mapping score -> count)
    score_distribution = {str(i): 0 for i in range(total_questions + 1)} # Initialize keys 0 to total_questions
    for attempt in attempts:
        score_str = str(attempt.get("score", -1)) # Use -1 for safety if score missing
        if score_str in score_distribution:
            score_distribution[score_str] += 1
        else: # Should not happen with initialization, but good safeguard
            logger.warning(f"Attempt for {exam_id_upper} had unexpected score {score_str}. Ignored in distribution.")

    logger.info(f"Returning results for {exam_id_upper}: {total_attempts} attempts found.")
    return JSONResponse(content={
        "exam_id": exam_id_upper,
        "filename": quiz_record.get("filename", "N/A"),
        "attempts": total_attempts,
        "average_score": average_score,
        "average_percentage": average_percentage,
        "total_questions": total_questions,
        "score_distribution": score_distribution
     })


# ==============================================================================
# Main Execution Guard (for direct script run checks)
# ==============================================================================
if __name__ == "__main__":
    # Configure Loguru for better console output if run directly
    # Example: logger.add(sys.stderr, format="{time} {level} {message}", level="INFO")
    logger.info("Script executed directly. Performing startup checks...")
    # --- Check directories ---
    if not STATIC_DIR.is_dir(): logger.warning(f"Static directory missing: {STATIC_DIR.resolve()}")
    if not TEMPLATES_DIR.is_dir(): logger.warning(f"Templates directory missing: {TEMPLATES_DIR.resolve()}")
    # --- Perform Model Loading Checks ---
    logger.info("--- Checking Embedding Model ---"); load_embedding_model();
    logger.info("--- Checking Generation Models (T5 & Phi) ---"); load_generation_models();
    # --- Check OCR ---
    logger.info("--- Checking OCR Dependencies ---");
    if OCR_ENABLED: logger.info("OCR dependencies (pytesseract, pdf2image) seem available.")
    else: logger.warning("OCR dependencies NOT found. Image-based PDF processing will be disabled.")
    # --- Storage Warning ---
    logger.warning("--- Storage Note: Using IN-MEMORY storage. All data will be lost on restart. ---")
    logger.info("Checks finished.")
    logger.info("To start the web server, run using a ASGI server like Uvicorn:")
    logger.info("uvicorn main:app --reload --host 0.0.0.0 --port 8000")
    logger.info("(Replace 'main' with the actual Python filename if different)")











